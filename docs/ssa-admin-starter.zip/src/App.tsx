import { useEffect, useState } from 'react'
import { supabase } from './lib/supabaseClient'
import Wineries from './features/Wineries'

type View = 'wineries' | 'events' | 'routes'

export default function App() {
  const [session, setSession] = useState<any>(null)
  const [email, setEmail] = useState('')
  const [view, setView] = useState<View>('wineries')

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => setSession(s))
    return () => sub.subscription.unsubscribe()
  }, [])

  const sendMagicLink = async (e: React.FormEvent) => {
    e.preventDefault()
    const { error } = await supabase.auth.signInWithOtp({ email })
    if (error) alert(error.message)
    else alert('Magic link sent. Check your email.')
  }

  if (!session) {
    return (
      <div style={{ maxWidth: 420, margin: '10vh auto' }}>
        <h1>SSA Admin</h1>
        <p>Sign in to edit datasets.</p>
        <form onSubmit={sendMagicLink} className="stack">
          <input
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ width: '100%', padding: 10 }}
          />
          <button className="btn primary" type="submit">Send Magic Link</button>
        </form>
      </div>
    )
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', height: '100vh' }}>
      <aside className="sidebar">
        <div style={{ marginBottom: 16 }}>
          <strong>{session.user?.email}</strong><br />
          <button className="btn" onClick={() => supabase.auth.signOut()} style={{ marginTop: 8 }}>Sign out</button>
        </div>
        <nav className="stack" style={{ flexDirection: 'column', alignItems: 'stretch' }}>
          <button className="btn" onClick={() => setView('wineries')}>Wineries</button>
          <button className="btn" onClick={() => alert('Events screen coming next')}>Events</button>
          <button className="btn" onClick={() => alert('Routes screen coming next')}>Routes</button>
        </nav>
      </aside>
      <main className="main">
        {view === 'wineries' ? <Wineries /> : <p>Coming soon…</p>}
      </main>
    </div>
  )
}
