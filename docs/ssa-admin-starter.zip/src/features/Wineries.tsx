import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

type Winery = {
  id: string
  name: string
  slug: string | null
  region: string | null
  short_description: string | null
  website_url: string | null
  status: 'draft' | 'published' | 'archived'
  sort_order: number | null
  created_by: string | null
  created_at: string
  updated_at: string
  deleted_at: string | null
}

export default function Wineries() {
  const [rows, setRows] = useState<Winery[]>([])
  const [loading, setLoading] = useState(false)
  const [editing, setEditing] = useState<Winery | null>(null)
  const [q, setQ] = useState('')

  const load = async () => {
    setLoading(true)
    let query = supabase.from('wineries').select('*').is('deleted_at', null).order('sort_order', { ascending: true }).order('name')
    if (q.trim()) query = query.ilike('name', `%${q}%`)
    const { data, error } = await query
    if (error) alert(error.message)
    setRows(data ?? [])
    setLoading(false)
  }

  useEffect(() => { load() }, [q])

  const startNew = async () => {
    const { data: session } = await supabase.auth.getSession()
    setEditing({
      id: '',
      name: '',
      slug: '',
      region: '',
      short_description: '',
      website_url: '',
      status: 'draft',
      sort_order: 1000,
      created_by: session.session?.user.id ?? null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      deleted_at: null
    })
  }

  const save = async () => {
    if (!editing) return
    const payload = { ...editing }
    if (!payload.slug && payload.name) {
      payload.slug = payload.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
    }
    if (payload.id) {
      const { error } = await supabase.from('wineries').update(payload).eq('id', payload.id)
      if (error) { alert(error.message); return }
    } else {
      const { data, error } = await supabase.from('wineries').insert(payload).select().single()
      if (error) { alert(error.message); return }
      payload.id = data.id
    }
    setEditing(null)
    await load()
  }

  const publishRow = async (id: string) => {
    const { error } = await supabase.from('wineries').update({ status: 'published' }).eq('id', id)
    if (error) alert(error.message); else load()
  }

  const archiveRow = async (id: string) => {
    const { error } = await supabase.from('wineries').update({ status: 'archived' }).eq('id', id)
    if (error) alert(error.message); else load()
  }

  const softDelete = async (id: string) => {
    if (!confirm('Delete this winery? (soft delete)')) return
    const { error } = await supabase.from('wineries').update({ deleted_at: new Date().toISOString() }).eq('id', id)
    if (error) alert(error.message); else load()
  }

  return (
    <div>
      <h2>Wineries</h2>

      <div className="stack" style={{ marginBottom: 12 }}>
        <input placeholder="Search name…" value={q} onChange={(e)=>setQ(e.target.value)} style={{ flex: 1, padding: 8 }} />
        <button className="btn" onClick={startNew}>New</button>
        <button className="btn" onClick={load} disabled={loading}>{loading ? 'Loading…' : 'Refresh'}</button>
      </div>

      {!editing ? (
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Region</th>
              <th>Status</th>
              <th>Website</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id}>
                <td>{r.name}</td>
                <td>{r.region}</td>
                <td>{r.status}</td>
                <td>{r.website_url ? <a href={r.website_url} target="_blank">link</a> : '—'}</td>
                <td style={{ textAlign: 'right' }}>
                  <button className="btn" onClick={() => setEditing(r)}>Edit</button>{' '}
                  {r.status !== 'published' && <button className="btn" onClick={() => publishRow(r.id)}>Publish</button>}{' '}
                  {r.status !== 'archived' && <button className="btn" onClick={() => archiveRow(r.id)}>Archive</button>}{' '}
                  <button className="btn" onClick={() => softDelete(r.id)}>Delete</button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && !loading && (
              <tr><td colSpan={5}>No records.</td></tr>
            )}
          </tbody>
        </table>
      ) : (
        <div style={{ maxWidth: 720 }}>
          <h3>{editing.id ? 'Edit Winery' : 'New Winery'}</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <label>Name <input value={editing.name} onChange={e=>setEditing({...editing, name:e.target.value})} /></label>
            <label>Slug <input value={editing.slug ?? ''} onChange={e=>setEditing({...editing, slug:e.target.value})} /></label>
            <label>Region <input value={editing.region ?? ''} onChange={e=>setEditing({...editing, region:e.target.value})} /></label>
            <label>Website <input value={editing.website_url ?? ''} onChange={e=>setEditing({...editing, website_url:e.target.value})} /></label>
            <label>Sort Order <input type="number" value={editing.sort_order ?? 1000} onChange={e=>setEditing({...editing, sort_order:Number(e.target.value)})} /></label>
            <label>Status
              <select value={editing.status} onChange={e=>setEditing({...editing, status: e.target.value as any})}>
                <option value="draft">draft</option>
                <option value="published">published</option>
                <option value="archived">archived</option>
              </select>
            </label>
          </div>
          <label>Short Description
            <textarea value={editing.short_description ?? ''} onChange={e=>setEditing({...editing, short_description:e.target.value})} />
          </label>
          <div style={{ marginTop: 12 }}>
            <button className="btn primary" onClick={save}>Save</button>{' '}
            <button className="btn" onClick={()=>setEditing(null)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  )
}
